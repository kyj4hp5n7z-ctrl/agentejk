'use client';

import { useState } from 'react';

type Result = {
  title_catchy: string;
  whatsapp_text: string;
  facebook_text: string;
  feira_do_rolo_text: string;
  mercadolivre_desc: string;
  shopee_desc: string;
  instagram_caption: string;
  reels_script: string;
  art_idea: string;
  hashtags: string[];
  ai_consultant_tips: {
    objective: string;
    tone: string;
    price_analysis: string;
    best_platform: string;
    photo_tip: string;
  };
};

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }
  return (
    <button onClick={copy} className="mt-3 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm font-bold" type="button">
      {copied ? 'Copiado!' : 'Copiar texto'}
    </button>
  );
}

export default function GeneratorPage() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());

    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const json = await res.json();
      if (json.success) setResult(json.data);
      else alert(json.error || 'Não foi possível gerar os conteúdos.');
    } catch {
      alert('Erro de conexão. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const cards = result ? [
    ['Título chamativo', result.title_catchy],
    ['Texto para WhatsApp', result.whatsapp_text],
    ['Texto para Facebook / Feira do Rolo', `${result.facebook_text}\n\n${result.feira_do_rolo_text}`],
    ['Descrição para Mercado Livre', result.mercadolivre_desc],
    ['Descrição para Shopee', result.shopee_desc],
    ['Legenda para Instagram', `${result.instagram_caption}\n\n${result.hashtags.join(' ')}`],
    ['Roteiro para Reels/TikTok', result.reels_script],
    ['Ideia de arte', result.art_idea],
  ] : [];

  return (
    <div className="min-h-screen p-6 max-w-6xl mx-auto">
      <div className="mb-8">
        <p className="text-cyan-400 font-bold uppercase tracking-widest text-sm">VendaFlow AI</p>
        <h1 className="text-3xl md:text-5xl font-extrabold text-white mb-3">Criador Inteligente de Anúncios</h1>
        <p className="text-slate-400">Preencha os dados abaixo e deixe a IA estruturar uma campanha completa para vender mais.</p>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-900 p-6 rounded-2xl border border-slate-800">
        <div>
          <label className="block text-sm font-medium mb-2">Nome do Produto ou Serviço</label>
          <input name="productName" required defaultValue="Pneu 195/65/15" className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-white" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Marca</label>
          <input name="brand" required defaultValue="Golden Crown" className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-white" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Preço (R$)</label>
          <input name="price" required defaultValue="290,00" className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-white" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Cidade / Estado</label>
          <input name="city" required defaultValue="Hortolândia/SP" className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-white" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Objetivo</label>
          <select name="objective" className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-white" defaultValue="vender pelo WhatsApp, Facebook, Mercado Livre e Shopee">
            <option value="vender rápido">Vender rápido</option>
            <option value="gerar orçamento">Gerar orçamento</option>
            <option value="lançar promoção">Lançar promoção</option>
            <option value="vender pelo WhatsApp, Facebook, Mercado Livre e Shopee">WhatsApp + Facebook + Mercado Livre + Shopee</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Tom de Voz</label>
          <select name="tone" className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-white" defaultValue="promoção chamativa">
            <option value="promoção chamativa">Promoção Chamativa</option>
            <option value="profissional">Profissional</option>
            <option value="urgente">Urgente</option>
            <option value="popular e direto">Popular e Direto</option>
          </select>
        </div>
        <div className="md:col-span-2">
          <button type="submit" disabled={loading} className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-60 font-bold rounded-lg text-white transition-all shadow-lg shadow-blue-600/30">
            {loading ? 'Gerando conteúdos com IA...' : 'Gerar Anúncios Automáticos'}
          </button>
        </div>
      </form>

      {result && (
        <div className="mt-10 space-y-6">
          <div className="bg-slate-900 p-6 rounded-2xl border border-cyan-500/40">
            <h2 className="text-2xl font-bold text-cyan-400">Consultor de Vendas IA</h2>
            <p className="text-slate-300 mt-3">{result.ai_consultant_tips.price_analysis}</p>
            <p className="text-slate-300 mt-2">{result.ai_consultant_tips.best_platform}</p>
            <p className="text-slate-300 mt-2">{result.ai_consultant_tips.photo_tip}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {cards.map(([title, text]) => (
              <div key={title} className="p-5 bg-slate-900 rounded-2xl border border-slate-800">
                <h3 className="text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-3">{title}</h3>
                <p className="whitespace-pre-line text-slate-200">{text}</p>
                <CopyButton text={text} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
