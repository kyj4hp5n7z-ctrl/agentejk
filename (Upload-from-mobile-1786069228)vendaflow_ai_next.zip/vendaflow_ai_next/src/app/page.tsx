import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950">
      <section className="max-w-6xl mx-auto px-6 py-20">
        <div className="inline-flex rounded-full border border-cyan-400/30 px-4 py-2 text-cyan-300 text-sm font-semibold mb-6">
          VendaFlow AI • Anúncios com Inteligência Artificial
        </div>
        <h1 className="text-4xl md:text-7xl font-black tracking-tight max-w-4xl">
          Crie anúncios, postagens e mensagens de venda com IA.
        </h1>
        <p className="text-slate-300 text-lg md:text-xl mt-6 max-w-3xl leading-relaxed">
          Transforme produtos simples em anúncios profissionais para Mercado Livre,
          Shopee, Facebook, Instagram, WhatsApp e Feira do Rolo.
        </p>
        <div className="mt-10 flex flex-col sm:flex-row gap-4">
          <Link href="/generator" className="px-7 py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-center shadow-lg shadow-blue-600/30">
            Criar meu primeiro anúncio
          </Link>
          <a href="https://wa.me/5519982568736" className="px-7 py-4 rounded-xl border border-slate-700 hover:border-cyan-400 text-white font-bold text-center">
            Falar no WhatsApp
          </a>
        </div>
        <div className="grid md:grid-cols-3 gap-5 mt-16">
          {[
            ['Mercado Livre e Shopee', 'Textos otimizados para marketplace.'],
            ['Facebook e Instagram', 'Legendas, posts, stories e roteiros.'],
            ['WhatsApp', 'Mensagens prontas para responder e fechar venda.'],
          ].map(([title, desc]) => (
            <div key={title} className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6">
              <h2 className="text-xl font-bold text-cyan-400">{title}</h2>
              <p className="text-slate-400 mt-2">{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
