import { NextResponse } from 'next/server';

type RequestBody = {
  productName?: string;
  brand?: string;
  price?: string;
  city?: string;
  objective?: string;
  tone?: string;
};

function safeText(value: unknown) {
  return String(value || '').trim();
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as RequestBody;
    const productName = safeText(body.productName) || 'Produto';
    const brand = safeText(body.brand) || 'Marca';
    const price = safeText(body.price) || '0,00';
    const city = safeText(body.city) || 'sua cidade';
    const objective = safeText(body.objective) || 'vender rápido';
    const tone = safeText(body.tone) || 'promoção chamativa';

    const mockAiResponse = {
      title_catchy: `${productName} ${brand} Novo — R$ ${price} em ${city}`,
      whatsapp_text: `Olá! Temos ${productName} ${brand} por apenas R$ ${price}. Produto novo, com ótimo custo-benefício e atendimento em ${city}. Chame agora e consulte disponibilidade!`,
      facebook_text: `🔥 PROMOÇÃO EM ${city.toUpperCase()}!\n\n${productName} ${brand}\n✅ Produto novo\n✅ Ótimo custo-benefício\n✅ Ideal para quem quer qualidade e economia\n💰 Apenas R$ ${price}\n📲 Chame no WhatsApp e garanta o seu!`,
      feira_do_rolo_text: `Vendo ${productName} ${brand} novo por R$ ${price}. Retirada ou atendimento em ${city}. Interessados chamem no WhatsApp. Produto com preço de promoção!`,
      mercadolivre_desc: `${productName} ${brand}\n\nProduto novo, ideal para quem procura qualidade, segurança e bom custo-benefício.\n\nCaracterísticas:\n- Produto: ${productName}\n- Marca: ${brand}\n- Condição: Novo\n- Local: ${city}\n\nAntes da compra, confirme compatibilidade, disponibilidade e prazo de envio.`,
      shopee_desc: `✅ ${productName} ${brand}\n✅ Produto novo\n✅ Ótimo preço\n✅ Excelente custo-benefício\n\n💰 Valor: R$ ${price}\n📍 ${city}\n\nCompre com segurança e confirme disponibilidade antes da compra.`,
      instagram_caption: `🚀 Promoção especial!\n\n${productName} ${brand} por apenas R$ ${price}.\n\nPerfeito para quem busca economia, qualidade e praticidade.\n\n📍 ${city}\n📲 Chame agora e consulte disponibilidade.`,
      reels_script: `Cena 1: Mostrar o produto de perto. Texto: Promoção especial!\nCena 2: Mostrar nome e marca. Texto: ${productName} ${brand}\nCena 3: Mostrar preço. Texto: Só R$ ${price}\nCena 4: Chamada final. Texto: Chame agora no WhatsApp!`,
      art_idea: `Criar arte chamativa com fundo escuro, detalhes em azul neon, produto em destaque, selo PROMOÇÃO, preço grande R$ ${price}, cidade ${city} e botão visual de WhatsApp.`,
      hashtags: ['#Promocao', '#VendasOnline', '#MercadoLivre', '#Shopee', '#FacebookMarketplace', '#WhatsApp', `#${brand.replace(/\s+/g, '')}`],
      ai_consultant_tips: {
        objective,
        tone,
        price_analysis: 'O preço informado pode ser apresentado como oferta chamativa. Compare com concorrentes antes de publicar em marketplace.',
        best_platform: 'WhatsApp e Facebook tendem a gerar contato rápido. Mercado Livre e Shopee ajudam a dar alcance e confiança.',
        photo_tip: 'Use fotos reais, boa iluminação, fundo limpo e mostre detalhes do produto.'
      }
    };

    return NextResponse.json({ success: true, data: mockAiResponse });
  } catch {
    return NextResponse.json({ success: false, error: 'Erro ao processar inteligência artificial.' }, { status: 500 });
  }
}
